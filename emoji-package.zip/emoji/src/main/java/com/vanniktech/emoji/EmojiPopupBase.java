package com.vanniktech.emoji;

public interface EmojiPopupBase {
    void start();
    void show();
    void dismiss();
    void stop();
}