package com.vanniktech.emoji_stickers.stickers;

public interface AddSticker {
    void addEvent();
}
