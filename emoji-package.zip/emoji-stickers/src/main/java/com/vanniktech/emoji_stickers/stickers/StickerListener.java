package com.vanniktech.emoji_stickers.stickers;

public interface StickerListener {
    void onClick(Sticker sticker);
    void onLongClick(Sticker sticker);
}
